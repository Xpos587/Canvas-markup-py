'''
Canvas-markup generates images.
'''

from .browser import Markup

__author__ = 'Xpos587'
__version__ = '1.0.1'
__email__ = 'x30827pos@gmail.com'